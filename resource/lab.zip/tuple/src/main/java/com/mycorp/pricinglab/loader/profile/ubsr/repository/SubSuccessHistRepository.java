package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubSuccessHist;
import com.vzwcorp.pricinglab.profile.vo.SubSuccessHistPK;

public interface SubSuccessHistRepository extends CrudRepository<SubSuccessHist, SubSuccessHistPK> {
}
