
package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubXltBlRbmDelrows;
import com.vzwcorp.pricinglab.profile.vo.SubXltBlRbmDelrowsPK;


public interface SubXltBlRbmDelrowsRepository extends CrudRepository<SubXltBlRbmDelrows, SubXltBlRbmDelrowsPK> {
	

}