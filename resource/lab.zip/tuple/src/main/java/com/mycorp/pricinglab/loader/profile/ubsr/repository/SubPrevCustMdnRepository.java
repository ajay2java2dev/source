package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubPrevCustMdn;
import com.vzwcorp.pricinglab.profile.vo.SubPrevCustMdnPK;

public interface SubPrevCustMdnRepository extends CrudRepository<SubPrevCustMdn, SubPrevCustMdnPK> {
}
