package com.vzwcorp.pricinglab.loader.profile.lookup.repository;

import org.springframework.data.repository.CrudRepository;
import com.vzwcorp.pricinglab.profile.lookup.vo.RefRgPlabConv;

public interface RefRgPlabConvRepository extends CrudRepository<RefRgPlabConv,Long> {
	
	

}
