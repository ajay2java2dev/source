package com.vzwcorp.pricinglab.adapter;

/**
 * Created by menonka on 8/19/2016.
 */
public class OutboundFileTransferAdapter {
}
