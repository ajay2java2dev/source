package com.vzwcorp.pricinglab.constants;

public enum OneMessageType {

	NightSurferWelcome,
	SelectYourSpeedWelcome,
	NightSurferExp1Day,
	SelectYourSpeedExp1Day,
	NightSurferExp7Days,
	SelectYourSpeedExp7Days,
	NightSurferEarlyTerm,
	SelectYourSpeedEarlyTerm,
	NightSurferExpire,
	SelectYourSpeedExpire

}
