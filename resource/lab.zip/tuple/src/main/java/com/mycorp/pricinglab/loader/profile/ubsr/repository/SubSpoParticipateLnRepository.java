package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubSpoParticipateLn;
import com.vzwcorp.pricinglab.profile.vo.SubSpoParticipateLnPK;

public interface SubSpoParticipateLnRepository extends CrudRepository<SubSpoParticipateLn, SubSpoParticipateLnPK> {
}
