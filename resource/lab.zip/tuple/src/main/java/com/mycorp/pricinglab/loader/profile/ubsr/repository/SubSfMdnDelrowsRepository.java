package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubSfMdnDelrows;
import com.vzwcorp.pricinglab.profile.vo.SubSfMdnDelrowsPk;

public interface SubSfMdnDelrowsRepository extends CrudRepository<SubSfMdnDelrows, SubSfMdnDelrowsPk> {
	
	
}
