package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubLnSvcProd;
import com.vzwcorp.pricinglab.profile.vo.SubLnSvcProdPK;

public interface SubLnSvcProdRepository extends CrudRepository<SubLnSvcProd, SubLnSvcProdPK> {
}
