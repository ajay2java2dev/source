package com.vzwcorp.pricinglab.profile.vo;

import java.util.List;

public class MDNProfile extends SubCustAcctMdn {

	List<SubCustDvcEqpTrans> dvcEquipment;
	List<SubCustDvcProvInfo> dvcProvInfo;
	List<SubSfMdn> sfos;

}
