package com.vzwcorp.pricinglab.loader.profile.rbm.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.rbm.vo.Acchaspolicyinstance;
import com.vzwcorp.pricinglab.profile.rbm.vo.AcchaspolicyinstancePK;

public interface AcchaspolicyinstanceRepository extends CrudRepository<Acchaspolicyinstance, AcchaspolicyinstancePK> {
}
