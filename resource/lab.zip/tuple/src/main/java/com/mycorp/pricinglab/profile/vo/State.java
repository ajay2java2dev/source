package com.vzwcorp.pricinglab.profile.vo;

public interface State {

}
