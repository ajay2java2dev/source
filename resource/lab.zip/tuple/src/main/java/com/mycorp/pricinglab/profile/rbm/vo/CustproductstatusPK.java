package com.vzwcorp.pricinglab.profile.rbm.vo;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CustproductstatusPK implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="EFFECTIVE_DTM")
	protected Timestamp	effectiveDtm;

	@Column(name="CUSTOMER_REF")
	protected String	customerRef;

	@Column(name="PRODUCT_SEQ")
	protected Long	productSeq;

	@Column(name="DOMAIN_ID")
	protected Long	domainId;

	public CustproductstatusPK() {}

	public CustproductstatusPK(Timestamp effectiveDtm, String customerRef, Long productSeq, Long domainId){
		 this.effectiveDtm = effectiveDtm;
		 this.customerRef = customerRef;
		 this.productSeq = productSeq;
		 this.domainId = domainId;
	}

	public Timestamp getEffectiveDtm() {
		return this.effectiveDtm;
	}

	public void setEffectiveDtm(Timestamp effectiveDtm) {
		this.effectiveDtm = effectiveDtm;
	}

	public String getCustomerRef() {
		return this.customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	public Long getProductSeq() {
		return this.productSeq;
	}

	public void setProductSeq(Long productSeq) {
		this.productSeq = productSeq;
	}

	public Long getDomainId() {
		return this.domainId;
	}

	public void setDomainId(Long domainId) {
		this.domainId = domainId;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CustproductstatusPK)) {
			return false;
		}
		CustproductstatusPK castOther = (CustproductstatusPK)other;
		return this.effectiveDtm.equals(castOther.effectiveDtm) && this.customerRef.equals(castOther.customerRef) && this.productSeq == castOther.productSeq && this.domainId == castOther.domainId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.effectiveDtm.hashCode();
		hash = hash * prime + this.customerRef.hashCode();
		hash = hash * prime + ((int) (this.productSeq ^ (this.productSeq >>> 32)));
		hash = hash * prime + ((int) (this.domainId ^ (this.domainId >>> 32)));
		return hash;
	}

}
