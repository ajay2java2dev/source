package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubImsiMdnTniRss;
import com.vzwcorp.pricinglab.profile.vo.SubImsiMdnTniRssPK;

public interface SubImsiMdnTniRssRepository extends CrudRepository<SubImsiMdnTniRss, SubImsiMdnTniRssPK> {
}
