package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubCustDvcEqpTrans;
import com.vzwcorp.pricinglab.profile.vo.SubCustDvcEqpTransPK;

public interface SubCustDvcEqpTransRepository extends CrudRepository<SubCustDvcEqpTrans, SubCustDvcEqpTransPK> {
}
