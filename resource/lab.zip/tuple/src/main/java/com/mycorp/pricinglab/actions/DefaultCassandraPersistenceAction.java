package com.vzwcorp.pricinglab.actions;

public class DefaultCassandraPersistenceAction {

}
