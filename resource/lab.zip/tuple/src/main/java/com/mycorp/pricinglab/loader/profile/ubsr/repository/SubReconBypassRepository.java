package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubReconBypass;
import com.vzwcorp.pricinglab.profile.vo.SubReconBypassPK;

public interface SubReconBypassRepository extends CrudRepository<SubReconBypass, SubReconBypassPK> {
}
