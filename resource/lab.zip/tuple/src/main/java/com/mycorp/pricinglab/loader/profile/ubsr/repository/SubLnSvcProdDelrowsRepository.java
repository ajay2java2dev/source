package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubLnSvcProdDelrows;
import com.vzwcorp.pricinglab.profile.vo.SubLnSvcProdDelrowsPK;

public interface SubLnSvcProdDelrowsRepository extends CrudRepository<SubLnSvcProdDelrows, SubLnSvcProdDelrowsPK> {
}
