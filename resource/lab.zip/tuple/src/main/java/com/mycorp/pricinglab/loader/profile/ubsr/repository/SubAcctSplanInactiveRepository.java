package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubAcctSplanInactive;
import com.vzwcorp.pricinglab.profile.vo.SubAcctSplanInactivePK;

public interface SubAcctSplanInactiveRepository extends CrudRepository<SubAcctSplanInactive, SubAcctSplanInactivePK> {
}
