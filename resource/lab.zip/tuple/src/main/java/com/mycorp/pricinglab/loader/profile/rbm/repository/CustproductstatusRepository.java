package com.vzwcorp.pricinglab.loader.profile.rbm.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.rbm.vo.Custproductstatus;
import com.vzwcorp.pricinglab.profile.rbm.vo.CustproductstatusPK;

public interface CustproductstatusRepository extends CrudRepository<Custproductstatus, CustproductstatusPK> {
}
