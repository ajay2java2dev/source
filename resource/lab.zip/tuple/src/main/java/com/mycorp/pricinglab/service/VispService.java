package com.vzwcorp.pricinglab.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.vzwcorp.pricinglab.vo.Service;
import com.vzwcorp.pricinglab.vo.ServiceInstance;

@org.springframework.stereotype.Service
public class VispService {

	public String addService(Service service) {
		return null;
	}

	// public String updateService(Service service) {
	// return null;
	// }
	//
	// public String removeService(Service service) {
	// return null;
	// }

	public String addServiceToDevice(ServiceInstance serviceInstance) {
		return null;
	}

	// public String removeServiceFromDevice(ServiceInstance productInstance) {
	// return null;
	// }

	public List<Service> listServices(Map<String, Object> criteria) {
		return new ArrayList<Service>();
	}
}
