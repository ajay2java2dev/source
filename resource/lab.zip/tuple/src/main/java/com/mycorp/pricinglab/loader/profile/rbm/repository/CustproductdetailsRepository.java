package com.vzwcorp.pricinglab.loader.profile.rbm.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.rbm.vo.Custproductdetails;
import com.vzwcorp.pricinglab.profile.rbm.vo.CustproductdetailsPK;

public interface CustproductdetailsRepository extends CrudRepository<Custproductdetails, CustproductdetailsPK> {
}
