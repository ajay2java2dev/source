package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubLnPrimIdMdn;
import com.vzwcorp.pricinglab.profile.vo.SubLnPrimIdMdnPK;

public interface SubLnPrimIdMdnRepository extends CrudRepository<SubLnPrimIdMdn, SubLnPrimIdMdnPK> {
}
