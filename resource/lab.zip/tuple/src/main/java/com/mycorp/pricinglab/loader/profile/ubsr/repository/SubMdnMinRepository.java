package com.vzwcorp.pricinglab.loader.profile.ubsr.repository;

import org.springframework.data.repository.CrudRepository;

import com.vzwcorp.pricinglab.profile.vo.SubMdnMin;
import com.vzwcorp.pricinglab.profile.vo.SubMdnMinPK;

public interface SubMdnMinRepository extends CrudRepository<SubMdnMin, SubMdnMinPK> {
}
